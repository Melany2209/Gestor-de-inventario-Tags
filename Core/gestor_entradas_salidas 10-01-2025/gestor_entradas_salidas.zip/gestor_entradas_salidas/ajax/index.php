<?php 
//redireccionar 
header ('Location: ../vistas/login.php');
?>