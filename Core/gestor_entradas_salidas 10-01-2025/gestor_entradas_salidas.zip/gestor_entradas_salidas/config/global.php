<?php 
//Ip de la pc servidor de base de datos
define("DB_HOST","localhost");

//Nombre de la base de datos
define("DB_NAME", "gestor_entradas_salidas");

//Usuario de la base de datos
define("DB_USERNAME", "gestor_entradas_salidas_user");

//Contrase�0�9a del usuario de la base de datos
define("DB_PASSWORD", "gestor_entradas_salidas@.*");

//definimos la codificación de los caracteres
define("DB_ENCODE","utf8");

//Definimos una constante como nombre del proyecto
define("PRO_NOMBRE","");
?>